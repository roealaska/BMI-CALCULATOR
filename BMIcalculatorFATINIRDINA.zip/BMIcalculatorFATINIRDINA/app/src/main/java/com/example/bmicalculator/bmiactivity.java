package com.example.bmicalculator;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.text.Html;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

public class bmiactivity extends AppCompatActivity {



    TextView mbmidisplay,magedisplay,mweightdisplay,mheightdisplay,mbmicategory,mgender, mbmirisk;
    Button mgotomain, mgotohome;
    Intent intent;

    ImageView mimageview;
    String mbmi;
    String cateogory;
    String risk;
    float intbmi;

    String height;
    String weight;

    float intheight,intweight;

    RelativeLayout mbackground;

    @SuppressLint("ResourceAsColor")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bmiactivity);
        getSupportActionBar().setElevation(0);
        ColorDrawable colorDrawable=new ColorDrawable(Color.parseColor("#1c1c1c"));
        getSupportActionBar().setBackgroundDrawable(colorDrawable);


       getSupportActionBar().setTitle(Html.fromHtml("<font color=\"white\"></font>"));
       getSupportActionBar().setTitle("Result");


        intent=getIntent();
        mbmidisplay=findViewById(R.id.bmidisplay);

        mbmicategory = findViewById(R.id.bmicategorydispaly);
        mbmirisk = findViewById(R.id.bmiriskdisplay);
        mgotomain=findViewById(R.id.gotomain);
        mgotohome=findViewById(R.id.gotohome);

        mimageview=findViewById(R.id.imageview);


        mgender=findViewById(R.id.genderdisplay);
        mbackground=findViewById(R.id.contentlayout);


        height=intent.getStringExtra("height");
        weight=intent.getStringExtra("weight");


        intheight=Float.parseFloat(height);
        intweight=Float.parseFloat(weight);

        intheight=intheight/100;
        intbmi=intweight/(intheight*intheight);

        //Change to 2 Decimal Places
        mbmi= String.format("%.2f", intbmi);
        System.out.println(mbmi);

        if(intbmi<18.4)
        {
            mbmicategory.setText("BMI Category: Underweight");
            mbmirisk.setText("Health Risk: Malnutrition risk");
            mimageview.setImageResource(R.drawable.warning2);

        }
        else if(intbmi<24.9 && intbmi>18.5 )
        {
            mbmicategory.setText("BMI Category: Normal Weight");
            mbmirisk.setText("Health Risk: Low risk");
            mimageview.setImageResource(R.drawable.ok1);
        }
        else if(intbmi <29.9 && intbmi>25)
        {
            mbmicategory.setText("BMI Category: Overweight");
            mbmirisk.setText("Health Risk: Enhanced risk");
            mimageview.setImageResource(R.drawable.warning2);
        }
        else if(intbmi<34.9 && intbmi>30)
        {
            mbmicategory.setText("BMI Category: Moderately obese");
            mbmirisk.setText("Health Risk: Medium risk");
            mimageview.setImageResource(R.drawable.warning2);
        }
        else if(intbmi<39.9 && intbmi>35)
        {
            mbmicategory.setText("BMI Category: Severely obese");
            mbmirisk.setText("Health Risk: High risk");
            mimageview.setImageResource(R.drawable.cross2);
        }
        else
        {
            mbmicategory.setText("BMI Category: Very severely obese");
            mbmirisk.setText("Health Risk: Very High risk");
            mimageview.setImageResource(R.drawable.cross2);
        }

        mgender.setText(intent.getStringExtra("gender"));
        mbmidisplay.setText(mbmi);


        mgotomain.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent1=new Intent(getApplicationContext(),MainActivity.class);
                startActivity(intent1);
            }
        });

        mgotohome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent2=new Intent(getApplicationContext(),Home.class);
                startActivity(intent2);
            }
        });



    }
}